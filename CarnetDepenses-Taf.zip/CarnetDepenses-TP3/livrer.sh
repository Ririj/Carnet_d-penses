#!/usr/bin/env bash
# TP 3 BACKEND - CarnetDepenses (.NET MAUI) - version macOS / Linux de livrer.ps1
# Utilisation :  bash livrer.sh [dossier_projet] [nom_depot]
# Variables : SANS_PAUSE=1  SANS_BUILD=1  SANS_PUSH=1
set -euo pipefail

RACINE="$(cd "$(dirname "$0")" && pwd)"
SNAP="$RACINE/snapshots"
DOSSIER="${1:-$HOME/Projets/CarnetDepenses}"
NOM_DEPOT="${2:-CarnetDepenses-TP3}"

info() { printf '\n\033[36m>> %s\033[0m\n' "$1"; }
ok()   { printf '   \033[32mOK\033[0m  %s\n' "$1"; }
die()  { printf '\n\033[31mERREUR : %s\033[0m\n' "$1"; exit 1; }

info "Vérification des outils"
command -v dotnet >/dev/null || die "dotnet introuvable"
command -v git >/dev/null || die "git introuvable"
git config user.name >/dev/null || die 'git config --global user.name "Ton Nom"'
git config user.email >/dev/null || die 'git config --global user.email "ton@email"'
[ -e "$DOSSIER" ] && die "Le dossier $DOSSIER existe déjà."

info "Création du projet MAUI (sans contenu d'exemple)"
dotnet new maui -n CarnetDepenses -o "$DOSSIER"
cd "$DOSSIER"
dotnet new gitignore
git init -q && git checkout -q -b main
TFM="$(grep -oE 'net[0-9]+\.[0-9]+-android' CarnetDepenses.csproj | head -1)"
[ -n "$TFM" ] || die "Cible Android introuvable (workload maui installé ?)"
ok "Cible de compilation de contrôle : $TFM"

etape() {  # dossier tag message test
  info "$3"
  cp -R "$SNAP/$1/." "$DOSSIER/"
  for s in Models Services; do
    if [ "$(ls -A "$s" | grep -v '^.gitkeep$' | wc -l)" -gt 0 ]; then rm -f "$s/.gitkeep"; fi
  done
  if [ "$1" = "03-phaseC" ]; then
    dotnet add package sqlite-net-pcl
    dotnet add package SQLitePCLRaw.bundle_green
  fi
  [ "${SANS_BUILD:-0}" = 1 ] || { dotnet build -f "$TFM" -nologo -v q; ok "Compilation $TFM réussie"; }
  if [ "${SANS_PAUSE:-0}" != 1 ]; then
    printf '   \033[33mA TESTER : %s\033[0m\n' "$4"; read -r -p "   Entrée pour committer (Ctrl+C pour arrêter) "
  fi
  git add -A && git commit -q -m "$3" && git tag "$2"
  ok "commit + tag $2"
}

etape 00-etape0 etape-0 "Étape 0 : projet MAUI CarnetDepenses + BaseViewModel, RelayCommand, RelayCommandP" \
  "L'app démarre (page vide du modèle)."
etape 01-phaseA phase-A "Phase A : persistance locale JSON (Depense, IDepenseRepository, JsonDepenseRepository, DepensesViewModel, MainPage, injection de dépendances)" \
  "Ajoute 2 dépenses, FERME l'app, relance : la liste réapparaît. Supprime avec X."
etape 02-phaseB phase-B "Phase B : consommation d'une API simulée (TauxReponse, FakeApiHandler, ApiService, conversion EUR, cache hors ligne)" \
  "Convertir : spinner 1,5 s puis total EUR. SimulerPanne=true, relance : 'Hors ligne : dernier taux connu'. Remets false."
etape 03-phaseC phase-C "Phase C : persistance SQLite (sqlite-net-pcl, SqliteDepenseRepository) - une seule ligne changée dans MauiProgram" \
  "Ajoute, ferme, relance : données relues depuis depenses.db3."
etape 04-feat1-categories ajout-1 "Ajout 1 : catégories de dépenses, plus gros poste, liste enrichie (catégorie, date, FCFA) et état vide" \
  "Catégorie affichée sous le libellé, 'Plus gros poste' à jour."
etape 05-feat2-confirmation ajout-2 "Ajout 2 : confirmation avant suppression via IDialogService (le ViewModel ne connaît pas les pages)" \
  "X -> dialogue. Annuler garde la ligne, Supprimer l'enlève."
etape 06-feat3-devises ajout-3 "Ajout 3 : conversion du total en EUR ou USD, cache par devise" \
  "USD puis convertir : total en USD."
etape 07-feat4-mode-panne ajout-4 "Ajout 4 : interrupteur de simulation de panne réseau dans l'écran" \
  "Interrupteur actif + convertir : message hors ligne + (cache)."
etape 08-feat5-saisie-robuste ajout-5 "Ajout 5 : saisie du montant robuste (virgule ou point, montant positif, message d'erreur)" \
  "'abc' ou '0' -> message rouge ; '12,5' et '12.5' acceptés."

info "Documentation (README + captures)"
mkdir -p docs/captures
cp "$RACINE/docs/README.md" README.md
if [ "${SANS_PAUSE:-0}" != 1 ]; then
  echo "   Dépose les captures dans $DOSSIER/docs/captures et le PDF dans docs/, colle le lien vidéo dans README.md"
  read -r -p "   Entrée quand c'est prêt "
fi
git add -A && git commit -q -m "Docs : README, captures d'écran en simulation et lien de la vidéo de démonstration"
ok "commit docs"

[ "${SANS_PUSH:-0}" = 1 ] && { info "Publication ignorée"; git log --oneline --decorate; exit 0; }
info "Publication sur GitHub (dépôt PUBLIC $NOM_DEPOT)"
if command -v gh >/dev/null; then
  gh auth status >/dev/null 2>&1 || gh auth login
  gh repo create "$NOM_DEPOT" --public --source . --remote origin --push
  git push -q origin --tags
  ok "Dépôt publié : $(gh repo view --json url -q .url)"
else
  echo "   Crée le dépôt PUBLIC $NOM_DEPOT sur https://github.com/new (sans README), puis :"
  echo "     git remote add origin https://github.com/<ton-compte>/$NOM_DEPOT.git && git push -u origin main && git push origin --tags"
fi
git log --oneline --decorate
