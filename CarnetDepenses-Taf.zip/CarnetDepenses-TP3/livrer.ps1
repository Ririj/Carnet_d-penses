﻿<#
  TP 3 BACKEND - CarnetDepenses (.NET MAUI)
  Crée le projet, applique le code phase par phase, compile, te laisse tester
  dans l'émulateur, puis commit + tag chaque phase, et publie sur GitHub (public).

  Utilisation (PowerShell, dans le dossier qui contient ce script) :
      Set-ExecutionPolicy -Scope Process Bypass
      .\livrer.ps1
  Options :
      -Dossier  C:\chemin\CarnetDepenses   (dossier du projet à créer)
      -NomDepot CarnetDepenses-TP3         (nom du dépôt GitHub)
      -SansPause   enchaîne sans s'arrêter pour tester chaque phase
      -SansBuild   ne compile pas avant chaque commit (déconseillé)
      -SansPush    ne publie pas sur GitHub
#>
param(
    [string]$Dossier  = (Join-Path $HOME "source\repos\CarnetDepenses"),
    [string]$NomDepot = "CarnetDepenses-TP3",
    [switch]$SansPause,
    [switch]$SansBuild,
    [switch]$SansPush
)

$ErrorActionPreference = "Stop"
$Racine = $PSScriptRoot
$Snap   = Join-Path $Racine "snapshots"

function Info($t)  { Write-Host "`n>> $t" -ForegroundColor Cyan }
function Ok($t)    { Write-Host "   OK  $t" -ForegroundColor Green }
function Stop-Erreur($t) { Write-Host "`nERREUR : $t" -ForegroundColor Red; exit 1 }
function Exec($cmd, $args2) {
    & $cmd @args2
    if ($LASTEXITCODE -ne 0) { Stop-Erreur "$cmd $($args2 -join ' ') a échoué." }
}

# ---------- 1. Prérequis ----------
Info "Vérification des outils"
foreach ($outil in "dotnet", "git") {
    if (-not (Get-Command $outil -ErrorAction SilentlyContinue)) { Stop-Erreur "$outil introuvable dans le PATH." }
}
Ok "dotnet $(dotnet --version), $(git --version)"
if (-not (git config user.name))  { Stop-Erreur 'Configure Git : git config --global user.name "Ton Nom"' }
if (-not (git config user.email)) { Stop-Erreur 'Configure Git : git config --global user.email "ton@email"' }
if (Test-Path $Dossier) { Stop-Erreur "Le dossier $Dossier existe déjà. Choisis-en un autre avec -Dossier." }

# ---------- 2. Étape 0 : projet MAUI vierge ----------
Info "Création du projet MAUI (sans contenu d'exemple)"
Exec "dotnet" @("new", "maui", "-n", "CarnetDepenses", "-o", $Dossier)
Push-Location $Dossier
try {
    Exec "dotnet" @("new", "gitignore")
    Exec "git" @("init", "-q")
    Exec "git" @("checkout", "-q", "-b", "main")

    $csproj = Get-Content "CarnetDepenses.csproj" -Raw
    $tfm = [regex]::Match($csproj, "net\d+\.\d+-android").Value
    if (-not $tfm) { Stop-Erreur "Cible Android introuvable dans CarnetDepenses.csproj (workload maui installé ?)." }
    Ok "Cible de compilation de contrôle : $tfm"

    # ---------- 3. Phases ----------
    $etapes = @(
        @{ Dir = "00-etape0"; Tag = "etape-0"
           Msg = "Étape 0 : projet MAUI CarnetDepenses + BaseViewModel, RelayCommand, RelayCommandP"
           Test = "L'app démarre (page vide du modèle)." },
        @{ Dir = "01-phaseA"; Tag = "phase-A"
           Msg = "Phase A : persistance locale JSON (Depense, IDepenseRepository, JsonDepenseRepository, DepensesViewModel, MainPage, injection de dépendances)"
           Test = "Ajoute 2 dépenses -> total en FCFA. FERME complètement l'app, relance : la liste réapparaît. Supprime avec X." },
        @{ Dir = "02-phaseB"; Tag = "phase-B"
           Msg = "Phase B : consommation d'une API simulée (TauxReponse, FakeApiHandler, ApiService, conversion EUR, cache hors ligne)"
           Test = "Convertir : le spinner tourne 1,5 s puis le total EUR s'affiche. Passe SimulerPanne à true, relance, convertir : 'Hors ligne : dernier taux connu'. REMETS false ensuite." },
        @{ Dir = "03-phaseC"; Tag = "phase-C"
           Msg = "Phase C : persistance SQLite (sqlite-net-pcl, SqliteDepenseRepository) - une seule ligne changée dans MauiProgram"
           Test = "Ajoute des dépenses, ferme, relance : elles sont relues depuis depenses.db3."
           Avant = { Exec "dotnet" @("add", "package", "sqlite-net-pcl")
                     Exec "dotnet" @("add", "package", "SQLitePCLRaw.bundle_green") } },
        @{ Dir = "04-feat1-categories"; Tag = "ajout-1"
           Msg = "Ajout 1 : catégories de dépenses, plus gros poste, liste enrichie (catégorie, date, FCFA) et état vide"
           Test = "Choisis une catégorie, ajoute : elle s'affiche sous le libellé ; 'Plus gros poste' se met à jour." },
        @{ Dir = "05-feat2-confirmation"; Tag = "ajout-2"
           Msg = "Ajout 2 : confirmation avant suppression via IDialogService (le ViewModel ne connaît pas les pages)"
           Test = "X -> boîte de dialogue. Annuler : la ligne reste. Supprimer : elle part." },
        @{ Dir = "06-feat3-devises"; Tag = "ajout-3"
           Msg = "Ajout 3 : conversion du total en EUR ou USD, cache par devise"
           Test = "Choisis USD, convertir : total en USD." },
        @{ Dir = "07-feat4-mode-panne"; Tag = "ajout-4"
           Msg = "Ajout 4 : interrupteur de simulation de panne réseau dans l'écran"
           Test = "Active l'interrupteur, convertir : message hors ligne + valeur (cache). Désactive : retour normal." },
        @{ Dir = "08-feat5-saisie-robuste"; Tag = "ajout-5"
           Msg = "Ajout 5 : saisie du montant robuste (virgule ou point, montant positif, message d'erreur)"
           Test = "Montant 'abc' ou '0' -> message rouge, rien n'est ajouté. '12,5' et '12.5' sont acceptés." }
    )

    foreach ($e in $etapes) {
        Info $e.Msg
        Copy-Item -Path (Join-Path $Snap "$($e.Dir)\*") -Destination $Dossier -Recurse -Force
        foreach ($sous in "Models", "Services") {
            $files = Get-ChildItem $sous -File -ErrorAction SilentlyContinue
            if (($files | Where-Object Name -ne ".gitkeep").Count -gt 0) { Remove-Item (Join-Path $sous ".gitkeep") -ErrorAction SilentlyContinue }
        }
        if ($e.Avant) { & $e.Avant }
        if (-not $SansBuild) {
            Exec "dotnet" @("build", "-f", $tfm, "-nologo", "-v", "q")
            Ok "Compilation $tfm réussie"
        }
        if (-not $SansPause) {
            Write-Host "   A TESTER dans l'émulateur (Visual Studio > F5) : $($e.Test)" -ForegroundColor Yellow
            Read-Host "   Entrée pour committer cette étape (Ctrl+C pour arrêter)" | Out-Null
        }
        Exec "git" @("add", "-A")
        Exec "git" @("commit", "-q", "-m", $e.Msg)
        Exec "git" @("tag", $e.Tag)
        Ok "commit + tag $($e.Tag)"
    }

    # ---------- 4. Documentation ----------
    Info "Documentation (README + captures)"
    New-Item -ItemType Directory -Force -Path "docs\captures" | Out-Null
    Copy-Item (Join-Path $Racine "docs\README.md") -Destination "README.md" -Force
    if (-not $SansPause) {
        Write-Host "   Dépose tes captures PNG dans $Dossier\docs\captures (noms 01-...png à 10-...png)" -ForegroundColor Yellow
        Write-Host "   et le PDF dans $Dossier\docs, puis colle le lien de la vidéo dans README.md." -ForegroundColor Yellow
        Read-Host "   Entrée quand c'est prêt (ou Entrée tout de suite : tu pourras les ajouter plus tard)" | Out-Null
    }
    Exec "git" @("add", "-A")
    Exec "git" @("commit", "-q", "-m", "Docs : README, captures d'écran en simulation et lien de la vidéo de démonstration")
    Ok "commit docs"

    # ---------- 5. Publication GitHub ----------
    if ($SansPush) { Info "Publication ignorée (-SansPush)."; return }
    Info "Publication sur GitHub (dépôt PUBLIC $NomDepot)"
    $gh = Get-Command gh -ErrorAction SilentlyContinue
    if ($gh) {
        & gh auth status 2>$null
        if ($LASTEXITCODE -ne 0) { Exec "gh" @("auth", "login") }
        Exec "gh" @("repo", "create", $NomDepot, "--public", "--source", ".", "--remote", "origin", "--push")
        Exec "git" @("push", "-q", "origin", "--tags")
        $url = (& gh repo view --json url -q .url)
        Ok "Dépôt publié : $url"
    } else {
        Write-Host @"
   GitHub CLI absent. Deux options :
   a) winget install GitHub.cli   puis relance seulement :  gh auth login ; gh repo create $NomDepot --public --source . --remote origin --push ; git push origin --tags
   b) Crée le dépôt PUBLIC $NomDepot sur https://github.com/new (sans README), puis :
        git remote add origin https://github.com/<ton-compte>/$NomDepot.git
        git push -u origin main
        git push origin --tags
"@ -ForegroundColor Yellow
    }
    Info "Historique :"
    git log --oneline --decorate
}
finally { Pop-Location }
