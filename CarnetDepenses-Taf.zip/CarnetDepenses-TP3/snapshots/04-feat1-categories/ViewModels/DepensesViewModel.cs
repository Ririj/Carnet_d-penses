using System.Collections.ObjectModel;
using Microsoft.Maui.Storage;
using CarnetDepenses.Models;
using CarnetDepenses.Services;

namespace CarnetDepenses.ViewModels;

public class DepensesViewModel : BaseViewModel
{
    private readonly IDepenseRepository _repo;
    private readonly IApiService _api;
    private string _libelle = "", _montantTexte = "";
    private bool _isBusy;
    private string _totalConverti = "", _message = "";
    private string _categorieChoisie = "Alimentation";

    public ObservableCollection<Depense> Depenses { get; } = new();

    public decimal Total => Depenses.Sum(d => d.Montant);

    // Ajout 1 : catégories de dépenses
    public IReadOnlyList<string> Categories { get; } = new[]
    {
        "Alimentation", "Transport", "Logement", "Santé", "Loisirs", "Autre"
    };

    public string CategorieChoisie
    {
        get => _categorieChoisie;
        set => SetField(ref _categorieChoisie, value);
    }

    // Catégorie qui pèse le plus dans le total (vide si aucune dépense).
    public string PlusGrosPoste
    {
        get
        {
            var poste = Depenses
                .GroupBy(d => string.IsNullOrEmpty(d.Categorie) ? "Autre" : d.Categorie)
                .Select(g => new { Categorie = g.Key, Somme = g.Sum(d => d.Montant) })
                .OrderByDescending(x => x.Somme)
                .FirstOrDefault();
            return poste is null ? "" : $"Plus gros poste : {poste.Categorie} ({poste.Somme:N0} FCFA)";
        }
    }

    public string Libelle
    {
        get => _libelle;
        set { if (SetField(ref _libelle, value)) AjouterCommand.Rafraichir(); }
    }

    public string MontantTexte
    {
        get => _montantTexte;
        set { if (SetField(ref _montantTexte, value)) AjouterCommand.Rafraichir(); }
    }

    public bool IsBusy
    {
        get => _isBusy;
        set { if (SetField(ref _isBusy, value)) ConvertirCommand.Rafraichir(); }
    }

    public string TotalConverti
    {
        get => _totalConverti;
        set => SetField(ref _totalConverti, value);
    }

    public string Message
    {
        get => _message;
        set => SetField(ref _message, value);
    }

    public RelayCommand AjouterCommand { get; }
    public RelayCommandP SupprimerCommand { get; }
    public RelayCommand ConvertirCommand { get; }

    // Le repository et le service API sont INJECTÉS par le conteneur.
    public DepensesViewModel(IDepenseRepository repo, IApiService api)
    {
        _repo = repo;
        _api = api;
        AjouterCommand = new RelayCommand(
            async () => await AjouterAsync(),
            () => !string.IsNullOrWhiteSpace(Libelle)
               && !string.IsNullOrWhiteSpace(MontantTexte));
        SupprimerCommand = new RelayCommandP(
            async p => await SupprimerAsync((Depense)p!));
        ConvertirCommand = new RelayCommand(
            async () => await ConvertirAsync(), () => !IsBusy);
    }

    // Relit le stockage et remplit la liste affichée.
    public async Task ChargerAsync()
    {
        Depenses.Clear();
        foreach (var d in await _repo.ListerAsync())
            Depenses.Add(d);
        NotifierTotaux();
    }

    private async Task AjouterAsync()
    {
        if (!decimal.TryParse(MontantTexte, out decimal m))
            return;
        var d = new Depense
        {
            Libelle = Libelle,
            Montant = m,
            Categorie = string.IsNullOrEmpty(CategorieChoisie) ? "Autre" : CategorieChoisie
        };
        await _repo.AjouterAsync(d);   // 1. on sauvegarde
        Depenses.Add(d);               // 2. on affiche
        NotifierTotaux();
        Libelle = ""; MontantTexte = "";
    }

    private async Task SupprimerAsync(Depense d)
    {
        await _repo.SupprimerAsync(d);
        Depenses.Remove(d);
        NotifierTotaux();
    }

    // Le total et le plus gros poste changent ensemble.
    private void NotifierTotaux()
    {
        OnPropertyChanged(nameof(Total));
        OnPropertyChanged(nameof(PlusGrosPoste));
    }

    private async Task ConvertirAsync()
    {
        IsBusy = true; Message = "";
        try
        {
            var t = await _api.GetTauxAsync();                    // appel réseau
            Preferences.Set("taux_eur", (double)t.Taux["EUR"]);   // cache
            TotalConverti = $"{Total * t.Taux["EUR"]:F2} EUR";
        }
        catch (HttpRequestException)                               // réseau coupé
        {
            double c = Preferences.Get("taux_eur", 0.0);
            if (c == 0) Message = "Hors ligne, pas de taux.";
            else
            {
                TotalConverti = $"{Total * (decimal)c:F2} EUR (cache)";
                Message = "Hors ligne : dernier taux connu.";
            }
        }
        finally { IsBusy = false; }                                // exécuté TOUJOURS
    }
}
