namespace CarnetDepenses.ViewModels;

// Commande qui reçoit un paramètre (CommandParameter) : utilisée pour
// supprimer LA dépense de la ligne sur laquelle on a cliqué.
public class RelayCommandP : System.Windows.Input.ICommand
{
    private readonly Action<object?> _exec;

    public RelayCommandP(Action<object?> exec) => _exec = exec;

    public bool CanExecute(object? p) => true;

    public void Execute(object? p) => _exec(p);

#pragma warning disable CS0067 // toujours exécutable : l'événement n'est jamais levé
    public event EventHandler? CanExecuteChanged;
#pragma warning restore CS0067
}
