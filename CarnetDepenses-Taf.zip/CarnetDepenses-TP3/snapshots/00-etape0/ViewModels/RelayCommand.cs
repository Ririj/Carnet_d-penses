using System.Windows.Input;

namespace CarnetDepenses.ViewModels;

// Commande sans paramètre (TP précédent, C2) :
// relie un bouton de la vue à une méthode du ViewModel.
public class RelayCommand : ICommand
{
    private readonly Action _execute;
    private readonly Func<bool>? _canExecute;

    public RelayCommand(Action execute, Func<bool>? canExecute = null)
    {
        _execute = execute;
        _canExecute = canExecute;
    }

    public event EventHandler? CanExecuteChanged;

    public bool CanExecute(object? parameter) => _canExecute?.Invoke() ?? true;

    public void Execute(object? parameter) => _execute();

    // Demande à la vue de réévaluer CanExecute (bouton actif / grisé).
    public void Rafraichir() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
}
