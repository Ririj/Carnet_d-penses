using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace CarnetDepenses.ViewModels;

// Classe de base de tous les ViewModels (TP précédent, C1) :
// prévient la vue qu'une propriété a changé (INotifyPropertyChanged).
public abstract class BaseViewModel : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    protected void OnPropertyChanged([CallerMemberName] string? nomPropriete = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nomPropriete));

    // Affecte le champ et notifie la vue. Renvoie true si la valeur a réellement changé.
    protected bool SetField<T>(ref T champ, T valeur, [CallerMemberName] string? nomPropriete = null)
    {
        if (EqualityComparer<T>.Default.Equals(champ, valeur))
            return false;

        champ = valeur;
        OnPropertyChanged(nomPropriete);
        return true;
    }
}
