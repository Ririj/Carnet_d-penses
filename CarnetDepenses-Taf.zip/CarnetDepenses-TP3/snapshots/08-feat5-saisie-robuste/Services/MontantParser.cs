using System.Globalization;
using System.Text.RegularExpressions;

namespace CarnetDepenses.Services;

// Ajout 5 : lecture robuste d'un montant saisi au clavier.
// Accepte "2500", "2 500", "12,5" ou "12.5" quelle que soit la langue du téléphone
// (decimal.TryParse seul dépend de la culture : "12.5" échoue sur un appareil en français).
public static class MontantParser
{
    private static readonly Regex Format = new(@"^\d{1,9}([.,]\d{1,2})?$");

    public static bool EssayerLire(string? texte, out decimal montant)
    {
        montant = 0;
        if (string.IsNullOrWhiteSpace(texte)) return false;

        // retire espaces normaux, insécables et fines insécables (séparateurs de milliers)
        string brut = texte.Replace(" ", "").Replace(" ", "").Replace(" ", "");
        if (!Format.IsMatch(brut)) return false;

        montant = decimal.Parse(brut.Replace(',', '.'), NumberStyles.AllowDecimalPoint,
                                CultureInfo.InvariantCulture);
        return montant > 0;
    }
}
