namespace CarnetDepenses.Services;

// Ajout 2 : le ViewModel ne doit pas connaître les pages.
// Il passe par ce contrat pour poser une question à l'utilisateur.
public interface IDialogService
{
    Task<bool> ConfirmerAsync(string titre, string message);
}
