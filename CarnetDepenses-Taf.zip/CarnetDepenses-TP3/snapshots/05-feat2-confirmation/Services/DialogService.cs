namespace CarnetDepenses.Services;

// Implémentation MAUI : affiche une boîte de dialogue sur la page courante.
public class DialogService : IDialogService
{
    public async Task<bool> ConfirmerAsync(string titre, string message)
    {
        var page = Application.Current?.Windows.FirstOrDefault()?.Page;
        if (page is null) return true;   // pas d'écran : on ne bloque pas l'action
        return await page.DisplayAlert(titre, message, "Supprimer", "Annuler");
    }
}
