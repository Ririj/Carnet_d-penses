using Microsoft.Extensions.Logging;
using CarnetDepenses.ViewModels;
using CarnetDepenses.Services;

namespace CarnetDepenses;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

#if DEBUG
        builder.Logging.AddDebug();
#endif

        // Injection de dépendances (A6)
        // Phase C : UNE SEULE ligne change (JSON -> SQLite). Le ViewModel et l'écran restent intacts.
        builder.Services.AddSingleton<IDepenseRepository, SqliteDepenseRepository>();
        // Phase B : HttpClient branché sur le faux serveur.
        // Vraie API plus tard : remplacer new FakeApiHandler() par rien, soit new HttpClient().
        builder.Services.AddSingleton(
            new HttpClient(new FakeApiHandler()));
        builder.Services.AddSingleton<IApiService, ApiService>();
        builder.Services.AddSingleton<IDialogService, DialogService>();   // ajout 2
        builder.Services.AddSingleton<DepensesViewModel>();
        builder.Services.AddSingleton<MainPage>();

        return builder.Build();
    }
}
