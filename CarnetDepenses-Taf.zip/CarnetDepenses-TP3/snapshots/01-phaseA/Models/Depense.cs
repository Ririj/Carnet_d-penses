namespace CarnetDepenses.Models;

// Une dépense du carnet.
public class Depense
{
    public int Id { get; set; }
    public string Libelle { get; set; } = "";
    public decimal Montant { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
}
