using System.Text.Json.Serialization;

namespace CarnetDepenses.Models;

// Forme de la réponse JSON renvoyée par l'API de taux de change.
public class TauxReponse
{
    [JsonPropertyName("base")]    // Nom exact de la clé dans le JSON reçu.
    public string Base { get; set; } = "";

    [JsonPropertyName("rates")]
    public Dictionary<string, decimal> Taux { get; set; } = new();
}
