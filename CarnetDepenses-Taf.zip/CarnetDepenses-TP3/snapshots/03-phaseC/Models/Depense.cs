using SQLite;

namespace CarnetDepenses.Models;

// Une dépense du carnet (table SQLite "Depense").
public class Depense
{
    [PrimaryKey, AutoIncrement]   // InsertAsync renseigne l'Id automatiquement
    public int Id { get; set; }
    public string Libelle { get; set; } = "";
    public decimal Montant { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
}
