# CarnetDepenses — TP 3 Backend : persistance, services et API

Atelier de développement mobile · .NET MAUI · architecture MVVM en couches
Auteur : Kamfo

Application de suivi des dépenses en FCFA : saisie, liste, total, persistance locale
(JSON puis SQLite), conversion du total via une API de taux de change (simulée), avec
gestion de la latence, des pannes réseau et d'un cache hors ligne.

**Vidéo de démonstration (30 s) :** _lien à coller ici_

---

## Architecture

```
MainPage.xaml  ──binding──▶  DepensesViewModel  ──interface──▶  IDepenseRepository
(Vue)                        (ViewModel)                         ├─ JsonDepenseRepository   (Phase A)
                                  │                              └─ SqliteDepenseRepository (Phase C)
                                  ├──interface──▶  IApiService ─▶ ApiService ─▶ HttpClient ─▶ FakeApiHandler (Phase B)
                                  └──interface──▶  IDialogService ─▶ DialogService (Ajout 2)
MauiProgram.cs : injection de dépendances (le seul endroit qui choisit les implémentations)
```

Le ViewModel ne connaît que des **interfaces**. Passer de JSON à SQLite ne change
**qu'une ligne** dans `MauiProgram.cs` : la vue et le ViewModel restent intacts.

## Historique : un commit (et un tag) par phase

| Tag | Contenu |
|---|---|
| `etape-0` | Projet MAUI sans contenu d'exemple, dossiers Models / Services / ViewModels, `BaseViewModel`, `RelayCommand`, `RelayCommandP` |
| `phase-A` | Persistance locale JSON : `Depense`, `IDepenseRepository`, `JsonDepenseRepository`, `DepensesViewModel`, `MainPage`, injection |
| `phase-B` | API simulée : `TauxReponse`, `FakeApiHandler` (latence 1,5 s, panne), `ApiService`, conversion EUR, cache `Preferences` |
| `phase-C` | SQLite : `sqlite-net-pcl` + `SQLitePCLRaw.bundle_green`, `SqliteDepenseRepository` |
| `ajout-1` … `ajout-5` | Fonctionnalités ajoutées (ci-dessous) |

## Fonctionnalités ajoutées

1. **Catégories** — chaque dépense a une catégorie (Picker) ; la liste affiche catégorie et date ; le « plus gros poste » est calculé ; message quand la liste est vide.
2. **Confirmation de suppression** — boîte de dialogue via `IDialogService` : le ViewModel reste testable et ne dépend d'aucune page.
3. **Choix de la devise** — conversion du total en EUR ou USD, avec un cache distinct par devise.
4. **Interrupteur « Simuler une panne réseau »** — teste le mode hors ligne depuis l'écran, sans modifier le code ni recompiler.
5. **Saisie robuste** — montant accepté avec virgule ou point (indépendant de la langue du téléphone), espaces de milliers tolérés, montant strictement positif, message d'erreur explicite.

## Lancer le projet

Prérequis : .NET SDK avec le workload MAUI (`dotnet workload install maui`), un émulateur Android.

```
dotnet build -t:Run -f net9.0-android      # adapter net9.0 à la version de ton SDK
```
ou ouvrir `CarnetDepenses.sln` dans Visual Studio, choisir l'émulateur Android, F5.

## Captures d'écran (mode simulation)

| | |
|---|---|
| ![](docs/captures/01-liste-vide.png) État initial | ![](docs/captures/02-saisie.png) Saisie avec catégorie |
| ![](docs/captures/03-liste-total.png) Liste, total, plus gros poste | ![](docs/captures/04-persistance-relance.png) Après fermeture et relance |
| ![](docs/captures/05-conversion-en-cours.png) Appel API en cours | ![](docs/captures/06-conversion-eur.png) Conversion EUR |
| ![](docs/captures/07-conversion-usd.png) Conversion USD | ![](docs/captures/08-hors-ligne-cache.png) Hors ligne : taux en cache |
| ![](docs/captures/09-confirmation-suppression.png) Confirmation de suppression | ![](docs/captures/10-erreur-saisie.png) Montant invalide refusé |

Document PDF des captures : [`docs/CarnetDepenses-captures.pdf`](docs/CarnetDepenses-captures.pdf)
